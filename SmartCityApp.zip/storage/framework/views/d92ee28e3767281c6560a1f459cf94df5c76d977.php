<!DOCTYPE html>
<html>

<head>
    <title>SPJR</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
    <h2 class="text-center">Data Laporan Jalan Rusak</h2>
    <table class="table table-bordered">
        <thead>
            <tr class="text-center">
                <th rowspan="2">No</th>
                <th rowspan="2">Nama Pelopor</th>
                <th colspan="2">Koordinat</th>
                <th rowspan="2">Lokasi</th>
                <th rowspan="2">Keterangan</th>
                <th rowspan="2">Kerusakan</th>
                <th rowspan="2">Status</th>
            </tr>
            <tr>
                <th>Latitude</th>
                <th>Longitude</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $no = 1;
            ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($datas->users->nama); ?></td>
                <td><?php echo e($datas->latitude); ?></td>
                <td><?php echo e($datas->longitude); ?></td>
                <td><?php echo e($datas->lokasi); ?></td>
                <td><?php echo e($datas->keterangan); ?></td>
                <td><?php echo e($datas->kerusakan); ?></td>
                <td><?php echo e($datas->status); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="float-right">
        <p class="text-center">Malang, <?php echo e($date); ?></p>
        
        <br><br><br>
        
    </div>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\SmartCityApp\resources\views/laporan/print.blade.php ENDPATH**/ ?>